#!/bin/bash

mono BasicBot.exe $1
